import { ZONES, type ZoneId } from './config';

export type QuestionId = 'budget' | 'payment' | 'interest' | 'visit';
export type Option = { value: string; label: string; points: number };
export type Question = { id: QuestionId; title: string; options: Option[] };
export type Answers = Partial<Record<QuestionId, string>>;
export type Level = 'inicial' | 'tibio' | 'caliente';

/**
 * Puntaje orientativo (máx. 100): presupuesto 20 + pago 30 + interés 15 + visita 35.
 * Es solo una guía interna para el asesor; NO garantiza una compra.
 */
export const QUESTIONS: Question[] = [
  {
    id: 'budget',
    title: '¿Cuál es tu presupuesto aproximado para el terreno?',
    options: [
      { value: 'b1', label: '$137,500 a $149,999', points: 20 },
      { value: 'b2', label: '$150,000 a $289,999', points: 20 },
      { value: 'b3', label: '$290,000 o más', points: 20 },
      { value: 'b0', label: 'Aún no lo defino', points: 0 },
    ],
  },
  {
    id: 'payment',
    title: '¿Cómo te gustaría pagar?',
    options: [
      { value: 'contado', label: 'De contado', points: 30 },
      { value: 'credito', label: 'Crédito a 24 meses', points: 20 },
      { value: 'opciones', label: 'Quiero conocer las opciones', points: 10 },
    ],
  },
  {
    id: 'interest',
    title: '¿Te gustaría conocer el desarrollo?',
    options: [
      { value: 'si', label: 'Sí, quiero conocerlo', points: 15 },
      { value: 'info', label: 'Primero quiero más información', points: 5 },
      { value: 'no', label: 'Por ahora solo estoy viendo', points: 0 },
    ],
  },
  {
    id: 'visit',
    title: '¿Quieres agendar una visita?',
    options: [
      { value: 'si', label: 'Sí, quiero agendar una visita', points: 35 },
      { value: 'luego', label: 'Tal vez más adelante', points: 15 },
      { value: 'no', label: 'Por ahora no', points: 0 },
    ],
  },
];

export function optionLabel(q: QuestionId, value: string | undefined): string {
  const question = QUESTIONS.find((x) => x.id === q);
  return question?.options.find((o) => o.value === value)?.label ?? '';
}

export function scoreAnswers(a: Answers): { score: number; level: Level } {
  let score = 0;
  for (const q of QUESTIONS) {
    const opt = q.options.find((o) => o.value === a[q.id]);
    if (opt) score += opt.points;
  }
  const level: Level = score >= 70 ? 'caliente' : score >= 40 ? 'tibio' : 'inicial';
  return { score, level };
}

export const LEVEL_LABEL: Record<Level, string> = {
  inicial: 'Lead inicial',
  tibio: 'Lead tibio',
  caliente: 'Lead caliente',
};

/** Zona sugerida según el presupuesto (orientativa, sujeta a disponibilidad). */
export function recommendZone(a: Answers): ZoneId {
  if (a.budget === 'b3') return 'grandes';
  if (a.budget === 'b2') return 'premium';
  return 'intermedia';
}

export function zoneName(id: ZoneId): string {
  return ZONES.find((z) => z.id === id)?.name ?? '';
}
