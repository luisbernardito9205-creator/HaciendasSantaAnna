/**
 * DATOS COMERCIALES Y DE CONTACTO — única fuente de verdad.
 * Para cambiar precios, textos o el número de WhatsApp, edita SOLO este archivo.
 */

export const CONTACT = {
  /** Número en formato internacional para wa.me (52 + 10 dígitos). */
  waNumber: '529621797743',
  /** Número tal como se muestra al público. */
  phoneDisplay: '962 179 7743',
} as const;

export const DEVELOPMENT = {
  name: 'HACIENDAS SANTA ANNA',
  developer: 'DESARROLLOS INMOBILIARIOS KAHT S.A. DE C.V.',
  location: 'Cantón El Sacrificio, municipio de Tuxtla Chico, Chiapas',
  /** Enlace de Google Maps proporcionado por la empresa. */
  mapsUrl: 'https://maps.app.goo.gl/8Gp5g3YGUSXigcgL8',
} as const;

export const PRICING = {
  /** Apartado desde (MXN). */
  deposit: 10000,
  /** Enganche (MXN), igual en las tres zonas. */
  downPayment: 35000,
  /** Único plazo de crédito disponible. */
  creditMonths: 24,
  /** Precio base más bajo del desarrollo (zona Intermedia). */
  lowestFrom: 137500,
} as const;

export type ZoneId = 'premium' | 'intermedia' | 'grandes';

export type Zone = {
  id: ZoneId;
  name: string;
  /** Precio desde (MXN), de contado. */
  from: number;
  surface: string;
  description: string;
  photos: { src: string; alt: string; width: number; height: number }[];
};

export const ZONES: Zone[] = [
  {
    id: 'premium',
    name: 'Premium',
    from: 150000,
    surface: 'Aprox. 250 y 259 m²',
    description: 'La zona más cercana a la entrada del desarrollo.',
    photos: [{ src: '/img/zona-premium.webp', alt: 'Terreno en zona Premium de Haciendas Santa Anna', width: 825, height: 1100 }],
  },
  {
    id: 'intermedia',
    name: 'Intermedia',
    from: 137500,
    surface: 'Aprox. 223 a 324 m²',
    description: 'Una alternativa para comenzar tu proyecto con una inversión inicial accesible.',
    photos: [
      { src: '/img/hero.webp', alt: 'Terreno en zona Intermedia de Haciendas Santa Anna', width: 1600, height: 1200 },
      { src: '/img/zona-intermedia-2.webp', alt: 'Otra vista de un terreno en zona Intermedia', width: 825, height: 1100 },
    ],
  },
  {
    id: 'grandes',
    name: 'Grandes Proyectos',
    from: 290000,
    surface: 'Desde aprox. 270 m² hasta aprox. 1,000 m²',
    description: 'Terrenos de mayor superficie para proyectos más grandes. Todo proyecto está sujeto a factibilidad, normatividad y permisos.',
    photos: [{ src: '/img/zona-grandes.webp', alt: 'Terreno en zona Grandes Proyectos de Haciendas Santa Anna', width: 1100, height: 825 }],
  },
];

export const GALLERY: { src: string; alt: string; width: number; height: number }[] = [
  { src: '/img/hero.webp', alt: 'Terreno de Haciendas Santa Anna con camino de terracería', width: 1600, height: 1200 },
  { src: '/img/zona-premium.webp', alt: 'Zona Premium de Haciendas Santa Anna', width: 825, height: 1100 },
  { src: '/img/zona-grandes.webp', alt: 'Zona Grandes Proyectos de Haciendas Santa Anna', width: 1100, height: 825 },
  { src: '/img/terreno-1.webp', alt: 'Vista del terreno de Haciendas Santa Anna', width: 1100, height: 825 },
  { src: '/img/zona-intermedia-2.webp', alt: 'Zona Intermedia de Haciendas Santa Anna', width: 825, height: 1100 },
  { src: '/img/terreno-2.webp', alt: 'Terreno de Haciendas Santa Anna', width: 825, height: 1100 },
];

export const PRICE_NOTE =
  'Precios desde, de contado, sujetos a disponibilidad y a las condiciones aplicables. Las superficies son aproximadas y pueden variar por terreno.';

/** Da formato de moneda sin depender del locale del navegador/servidor. */
export function money(n: number): string {
  return '$' + String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}
