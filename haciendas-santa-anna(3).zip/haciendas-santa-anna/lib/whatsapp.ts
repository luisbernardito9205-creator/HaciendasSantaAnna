import { CONTACT, PRICING, money } from './config';
import { LEVEL_LABEL, optionLabel, scoreAnswers, type Answers } from './quiz';

/** Enlace wa.me con el mensaje correctamente codificado. */
export function waLink(message: string): string {
  return `https://wa.me/${CONTACT.waNumber}?text=${encodeURIComponent(message)}`;
}

export const VISIT_MESSAGE =
  'Hola, vi la página de Haciendas Santa Anna y quisiera agendar una visita. ¿Me pueden dar información?';

export function zoneMessage(zoneName: string): string {
  return `Hola, me interesa la zona ${zoneName} de Haciendas Santa Anna. Quisiera recibir información y conocer disponibilidad.`;
}

export type LeadData = {
  name: string;
  phone: string;
  zone: string;
  budget: string;
  payment: string;
  visit: string;
  message: string;
  /** Respuestas del quiz, si el prospecto lo contestó. */
  quiz?: Answers;
};

export function leadMessage(d: LeadData): string {
  const lines = [
    'Hola, quisiera información de Haciendas Santa Anna.',
    `Nombre: ${d.name}`,
    `Teléfono: ${d.phone}`,
    `Zona de interés: ${d.zone}`,
    `Presupuesto: ${d.budget}`,
    `Forma de pago: ${d.payment}`,
    `Visita: ${d.visit}`,
  ];
  if (d.message.trim()) lines.push(`Mensaje: ${d.message.trim()}`);
  if (d.quiz && Object.keys(d.quiz).length > 0) {
    const { level } = scoreAnswers(d.quiz);
    lines.push(`Nivel de interés (orientativo): ${LEVEL_LABEL[level]}`);
  }
  return lines.join('\n');
}

export function quizMessage(a: Answers, zoneName: string): string {
  const { level } = scoreAnswers(a);
  return [
    `Hola, contesté el cuestionario de Haciendas Santa Anna y me sugirieron la zona ${zoneName}.`,
    `Presupuesto: ${optionLabel('budget', a.budget)}`,
    `Forma de pago: ${optionLabel('payment', a.payment)}`,
    `Conocer el desarrollo: ${optionLabel('interest', a.interest)}`,
    `Visita: ${optionLabel('visit', a.visit)}`,
    `Nivel de interés (orientativo): ${LEVEL_LABEL[level]}`,
    `Tengo entendido que el apartado es desde ${money(PRICING.deposit)} y el enganche de ${money(PRICING.downPayment)}. Quisiera conocer disponibilidad.`,
  ].join('\n');
}
