import Image from 'next/image';
import { Check, FileText, Lightbulb, MapPin, MessageCircle, Zap } from 'lucide-react';
import { CONTACT, DEVELOPMENT, GALLERY, PRICE_NOTE, PRICING, ZONES, money } from '@/lib/config';
import { VISIT_MESSAGE, waLink, zoneMessage } from '@/lib/whatsapp';

export function Header() {
  return (
    <header className="header">
      <div className="wrap header__bar">
        <a href="#inicio" className="header__logos" aria-label="Haciendas Santa Anna, inicio">
          <Image src="/img/logo-hsa.webp" alt="Haciendas Santa Anna" width={720} height={261} className="logo logo--hsa" priority />
          <span className="header__sep" aria-hidden="true" />
          <Image src="/img/logo-kaht.webp" alt="KAHT Desarrollos Inmobiliarios" width={720} height={534} className="logo logo--kaht" priority />
        </a>
        <a className="btn btn--primary btn--sm header__cta" href={waLink(VISIT_MESSAGE)} target="_blank" rel="noopener noreferrer">
          WhatsApp
        </a>
      </div>
      <nav className="nav" aria-label="Secciones">
        <div className="wrap nav__list">
          <a href="#zonas">Zonas</a>
          <a href="#pagos">Pagos</a>
          <a href="#beneficios">Beneficios</a>
          <a href="#galeria">Galería</a>
          <a href="#ubicacion">Ubicación</a>
          <a href="#quiz">Cuestionario</a>
          <a href="#contacto">Contacto</a>
        </div>
      </nav>
    </header>
  );
}

export function Hero() {
  return (
    <section id="inicio" className="hero">
      <Image src="/img/hero.webp" alt="" fill priority sizes="100vw" className="hero__img" />
      <div className="hero__shade" />
      <div className="wrap hero__content">
        <p className="kicker kicker--light">Terrenos en Chiapas</p>
        <h1>ENCUENTRA TU TERRENO EN HACIENDAS SANTA ANNA</h1>
        <p className="hero__sub">Conoce nuestras zonas y encuentra una alternativa para comenzar tu proyecto de inversión.</p>
        <ul className="chips">
          <li><strong>Terrenos desde {money(PRICING.lowestFrom)}</strong> MXN</li>
          <li><strong>Apartado desde {money(PRICING.deposit)}</strong> MXN</li>
          <li><strong>Enganche de {money(PRICING.downPayment)}</strong> MXN</li>
          <li><strong>Crédito a {PRICING.creditMonths} meses</strong></li>
        </ul>
        <div className="actions">
          <a className="btn btn--primary btn--lg" href={waLink(VISIT_MESSAGE)} target="_blank" rel="noopener noreferrer">
            <MessageCircle size={20} aria-hidden="true" /> AGENDA TU VISITA POR WHATSAPP
          </a>
          <a className="btn btn--ghost-light btn--lg" href="#zonas">Ver las zonas</a>
        </div>
        <p className="hero__fine">{PRICE_NOTE}</p>
      </div>
    </section>
  );
}

export function Zones() {
  return (
    <section id="zonas" className="section">
      <div className="wrap">
        <p className="kicker">Conoce las tres zonas</p>
        <h2>Elige la zona que va con tu proyecto</h2>
        <div className="zones">
          {ZONES.map((z) => (
            <article key={z.id} className="card zone">
              <div className={`zone__photos${z.photos.length > 1 ? ' zone__photos--two' : ''}`}>
                {z.photos.map((p) => (
                  <Image key={p.src} src={p.src} alt={p.alt} width={p.width} height={p.height} sizes="(max-width: 700px) 90vw, 360px" className="zone__img" />
                ))}
              </div>
              <div className="zone__body">
                <h3>{z.name}</h3>
                <p className="zone__price">
                  <span>Desde</span> <strong>{money(z.from)}</strong> <span>MXN</span>
                </p>
                <ul className="zone__terms">
                  <li>Enganche: <strong>{money(PRICING.downPayment)} MXN</strong></li>
                  <li>Apartado desde: <strong>{money(PRICING.deposit)} MXN</strong></li>
                </ul>
                <p className="zone__surface">{z.surface}</p>
                <p>{z.description}</p>
                <a className="btn btn--primary btn--full" href={waLink(zoneMessage(z.name))} target="_blank" rel="noopener noreferrer">
                  Solicitar información
                </a>
              </div>
            </article>
          ))}
        </div>
        <p className="fine">{PRICE_NOTE}</p>
      </div>
    </section>
  );
}

export function Payments() {
  return (
    <section id="pagos" className="section section--navy">
      <div className="wrap wrap--narrow">
        <p className="kicker kicker--light">Facilidades de pago</p>
        <h2>Elige la modalidad de pago que mejor se adapte a ti</h2>
        <div className="pay">
          <div className="pay__card">
            <h3>Contado</h3>
            <p>Paga el precio del terreno de una sola vez.</p>
          </div>
          <div className="pay__card">
            <h3>Crédito a {PRICING.creditMonths} meses</h3>
            <p>Enganche de {money(PRICING.downPayment)} MXN y el resto a {PRICING.creditMonths} meses.</p>
          </div>
        </div>
        <p className="pay__deposit">
          <Check size={20} aria-hidden="true" /> Aparta tu terreno desde <strong>{money(PRICING.deposit)} MXN</strong>
        </p>
        <a className="btn btn--primary btn--lg" href={waLink('Hola, quisiera una cotización personalizada de un terreno en Haciendas Santa Anna.')} target="_blank" rel="noopener noreferrer">
          Solicitar cotización personalizada
        </a>
        <p className="fine fine--light">Las condiciones aplicables se confirman con el asesor según el terreno seleccionado.</p>
      </div>
    </section>
  );
}

export function Benefits() {
  const items = [
    { icon: FileText, title: 'Escrituras públicas', text: 'Propiedad con escrituras públicas.' },
    { icon: Zap, title: 'Energía eléctrica', text: 'El desarrollo cuenta con energía eléctrica.' },
    { icon: Lightbulb, title: 'Alumbrado público', text: 'Cuenta con alumbrado público.' },
  ];
  return (
    <section id="beneficios" className="section">
      <div className="wrap">
        <p className="kicker">Beneficios del desarrollo</p>
        <h2>Lo que incluye Haciendas Santa Anna</h2>
        <div className="benefits">
          {items.map(({ icon: Icon, title, text }) => (
            <div key={title} className="card benefit">
              <Icon size={30} aria-hidden="true" />
              <h3>{title}</h3>
              <p>{text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export function Gallery() {
  return (
    <section id="galeria" className="section section--cream">
      <div className="wrap">
        <p className="kicker">Galería y video</p>
        <h2>Conoce el terreno</h2>
        <div className="video">
          <video controls playsInline preload="none" poster="/img/recorrido-poster.webp" aria-label="Recorrido real por Haciendas Santa Anna">
            <source src="/video/recorrido.mp4" type="video/mp4" />
            Tu navegador no puede reproducir este video.
          </video>
        </div>
        <div className="gallery">
          {GALLERY.map((p) => (
            <Image key={p.src} src={p.src} alt={p.alt} width={p.width} height={p.height} sizes="(max-width: 700px) 50vw, 300px" className="gallery__img" loading="lazy" />
          ))}
        </div>
      </div>
    </section>
  );
}

export function Location() {
  return (
    <section id="ubicacion" className="section">
      <div className="wrap wrap--narrow">
        <p className="kicker">Ubicación</p>
        <h2>Una ubicación que vale la pena conocer</h2>
        <p className="lead">
          <MapPin size={18} aria-hidden="true" className="inline-icon" /> {DEVELOPMENT.location}.
        </p>
        <div className="map">
          <Image src="/img/mapa-ruta.webp" alt="Captura de Google Maps con la ruta hacia Haciendas Santa Anna" width={753} height={900} sizes="(max-width: 700px) 90vw, 420px" loading="lazy" />
        </div>
        <p className="fine">Captura de Google Maps; el tiempo de traslado varía según el punto de salida.</p>
        <a className="btn btn--primary btn--lg" href={DEVELOPMENT.mapsUrl} target="_blank" rel="noopener noreferrer">
          Abrir ubicación en Google Maps
        </a>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="footer">
      <div className="wrap footer__inner">
        <div className="footer__logos">
          <Image src="/img/logo-hsa.webp" alt="Haciendas Santa Anna" width={720} height={261} className="logo logo--footer" loading="lazy" />
          <Image src="/img/logo-kaht.webp" alt="KAHT Desarrollos Inmobiliarios" width={720} height={534} className="logo logo--footer" loading="lazy" />
        </div>
        <p>Un desarrollo de {DEVELOPMENT.developer}</p>
        <p>{DEVELOPMENT.location}</p>
        <p>Teléfono y WhatsApp: <a href={`tel:+${CONTACT.waNumber}`}>{CONTACT.phoneDisplay}</a></p>
        <p><a href="/aviso-de-privacidad">Aviso de Privacidad</a></p>
      </div>
    </footer>
  );
}

export function StickyCta() {
  return (
    <a className="sticky" href={waLink(VISIT_MESSAGE)} target="_blank" rel="noopener noreferrer">
      <MessageCircle size={20} aria-hidden="true" /> AGENDA TU VISITA POR WHATSAPP
    </a>
  );
}
