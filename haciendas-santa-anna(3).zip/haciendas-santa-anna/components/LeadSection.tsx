'use client';

import { useEffect, useState, type FormEvent } from 'react';
import { ArrowLeft, CalendarCheck, MessageCircle } from 'lucide-react';
import { ZONES, PRICING, money } from '@/lib/config';
import { QUESTIONS, optionLabel, recommendZone, zoneName, type Answers } from '@/lib/quiz';
import { leadMessage, quizMessage, waLink } from '@/lib/whatsapp';

type Prefill = { zone: string; budget: string; payment: string; visit: string; answers: Answers };

function goTo(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/* ───────────────────────────── QUIZ ───────────────────────────── */
function Quiz({ onPrefill }: { onPrefill: (p: Prefill) => void }) {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Answers>({});
  const total = QUESTIONS.length;
  const done = step >= total;

  function pick(qid: (typeof QUESTIONS)[number]['id'], value: string) {
    const next: Answers = { ...answers, [qid]: value };
    setAnswers(next);
    setStep((s) => s + 1);
    if (step + 1 >= total) {
      const zone = zoneName(recommendZone(next));
      onPrefill({
        zone,
        budget: optionLabel('budget', next.budget),
        payment: optionLabel('payment', next.payment),
        visit: next.visit === 'si' ? 'Sí, quiero agendar una visita' : 'No por ahora',
        answers: next,
      });
    }
  }

  const zone = done ? zoneName(recommendZone(answers)) : '';
  const zoneData = ZONES.find((z) => z.name === zone);

  return (
    <section id="quiz" className="section section--cream">
      <div className="wrap wrap--narrow">
        <p className="kicker">Te ayudamos a elegir</p>
        <h2>¿Qué zona va con tu proyecto?</h2>
        <p className="lead">Responde 4 preguntas rápidas y te orientamos hacia una zona.</p>

        <div className="card quiz" aria-live="polite">
          {!done ? (
            <>
              <div className="progress" role="progressbar" aria-valuemin={0} aria-valuemax={total} aria-valuenow={step}>
                <span style={{ width: `${(step / total) * 100}%` }} />
              </div>
              <p className="quiz__count">Pregunta {step + 1} de {total}</p>
              <h3 className="quiz__q">{QUESTIONS[step].title}</h3>
              <div className="options">
                {QUESTIONS[step].options.map((o) => (
                  <button
                    key={o.value}
                    type="button"
                    className={`option${answers[QUESTIONS[step].id] === o.value ? ' option--on' : ''}`}
                    onClick={() => pick(QUESTIONS[step].id, o.value)}
                  >
                    {o.label}
                  </button>
                ))}
              </div>
              {step > 0 && (
                <button type="button" className="linkbtn" onClick={() => setStep((s) => s - 1)}>
                  <ArrowLeft size={16} aria-hidden="true" /> Regresar
                </button>
              )}
            </>
          ) : (
            <div className="result">
              <p className="kicker">Tu resultado</p>
              <h3 className="quiz__q">Te sugerimos conocer la zona {zone}</h3>
              {zoneData && (
                <p>
                  Desde {money(zoneData.from)} de contado · {zoneData.surface}. Es una orientación según tu presupuesto,
                  sujeta a disponibilidad; un asesor te confirmará las opciones. Apartado desde {money(PRICING.deposit)}.
                </p>
              )}
              <div className="actions">
                <a
                  className="btn btn--primary"
                  href={waLink(quizMessage(answers, zone))}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <MessageCircle size={18} aria-hidden="true" /> Continuar por WhatsApp
                </a>
                <button type="button" className="btn btn--ghost" onClick={() => goTo('contacto')}>
                  Completar mi solicitud
                </button>
              </div>
              <button
                type="button"
                className="linkbtn"
                onClick={() => {
                  setAnswers({});
                  setStep(0);
                }}
              >
                Volver a empezar
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

/* ─────────────────────────── FORMULARIO ─────────────────────────── */
const BUDGETS = QUESTIONS[0].options.map((o) => o.label);
const PAYMENTS = QUESTIONS[1].options.map((o) => o.label);
const VISITS = ['Sí, quiero agendar una visita', 'No por ahora'];

function ContactForm({ prefill }: { prefill: Prefill | null }) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [zone, setZone] = useState('');
  const [budget, setBudget] = useState('');
  const [payment, setPayment] = useState('');
  const [visit, setVisit] = useState(VISITS[0]);
  const [message, setMessage] = useState('');
  const [consent, setConsent] = useState(false);
  const [error, setError] = useState('');
  const [link, setLink] = useState('');

  useEffect(() => {
    if (!prefill) return;
    setZone(prefill.zone);
    setBudget(prefill.budget);
    setPayment(prefill.payment);
    setVisit(prefill.visit);
  }, [prefill]);

  function submit(e: FormEvent) {
    e.preventDefault();
    const digits = phone.replace(/\D/g, '');
    if (name.trim().length < 3) return setError('Escribe tu nombre completo.');
    if (digits.length < 10 || digits.length > 13) return setError('Escribe tu teléfono o WhatsApp con 10 dígitos.');
    if (!zone) return setError('Elige una zona de interés.');
    if (!budget) return setError('Elige tu presupuesto aproximado.');
    if (!payment) return setError('Elige tu forma de pago.');
    if (!consent) return setError('Debes aceptar el Aviso de Privacidad para continuar.');
    setError('');
    const url = waLink(
      leadMessage({
        name: name.trim(),
        phone: digits.slice(-10),
        zone,
        budget,
        payment,
        visit,
        message,
        quiz: prefill?.answers,
      }),
    );
    setLink(url);
    window.open(url, '_blank', 'noopener,noreferrer');
  }

  return (
    <section id="contacto" className="section">
      <div className="wrap wrap--narrow">
        <p className="kicker">Hablemos de tu terreno</p>
        <h2>Solicita información</h2>
        <p className="lead">Llena el formulario y continúa la conversación por WhatsApp con tu mensaje ya preparado.</p>

        <div className="card form">
          {link ? (
            <div className="result" aria-live="polite">
              <h3 className="quiz__q">¡Listo, {name.trim().split(' ')[0]}!</h3>
              <p>Si WhatsApp no se abrió, toca el botón para enviar tu mensaje a un asesor.</p>
              <a className="btn btn--primary" href={link} target="_blank" rel="noopener noreferrer">
                <MessageCircle size={18} aria-hidden="true" /> Continuar por WhatsApp
              </a>
              <button type="button" className="linkbtn" onClick={() => setLink('')}>
                Editar mis datos
              </button>
            </div>
          ) : (
            <form onSubmit={submit} noValidate>
              <label>
                Nombre completo
                <input type="text" autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} />
              </label>
              <label>
                Teléfono o WhatsApp
                <input
                  type="tel"
                  inputMode="tel"
                  autoComplete="tel-national"
                  placeholder="10 dígitos"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                />
              </label>
              <label>
                Zona de interés
                <select value={zone} onChange={(e) => setZone(e.target.value)}>
                  <option value="">Selecciona una zona</option>
                  {ZONES.map((z) => (
                    <option key={z.id} value={z.name}>{z.name}</option>
                  ))}
                </select>
              </label>
              <label>
                Presupuesto aproximado
                <select value={budget} onChange={(e) => setBudget(e.target.value)}>
                  <option value="">Selecciona un rango</option>
                  {BUDGETS.map((b) => (
                    <option key={b} value={b}>{b}</option>
                  ))}
                </select>
              </label>
              <label>
                Forma de pago
                <select value={payment} onChange={(e) => setPayment(e.target.value)}>
                  <option value="">Selecciona una opción</option>
                  {PAYMENTS.map((p) => (
                    <option key={p} value={p}>{p}</option>
                  ))}
                </select>
              </label>
              <label>
                Solicitud de visita
                <select value={visit} onChange={(e) => setVisit(e.target.value)}>
                  {VISITS.map((v) => (
                    <option key={v} value={v}>{v}</option>
                  ))}
                </select>
              </label>
              <label>
                Mensaje (opcional)
                <textarea rows={3} maxLength={300} value={message} onChange={(e) => setMessage(e.target.value)} />
              </label>
              <label className="check">
                <input type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)} />
                <span>
                  He leído y acepto el{' '}
                  <a href="/aviso-de-privacidad" target="_blank" rel="noopener noreferrer">Aviso de Privacidad</a> y
                  autorizo el uso de mis datos para recibir información de Haciendas Santa Anna.
                </span>
              </label>
              {error && <p className="error" role="alert">{error}</p>}
              <button type="submit" className="btn btn--primary btn--full">
                <CalendarCheck size={18} aria-hidden="true" /> Continuar por WhatsApp
              </button>
              <p className="fine">
                Esta página no guarda tus datos: se envían únicamente en el mensaje de WhatsApp que tú decides mandar.
              </p>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}

export default function LeadSection() {
  const [prefill, setPrefill] = useState<Prefill | null>(null);
  return (
    <>
      <Quiz onPrefill={setPrefill} />
      <ContactForm prefill={prefill} />
    </>
  );
}
