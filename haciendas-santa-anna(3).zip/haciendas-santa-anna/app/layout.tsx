import type { Metadata, Viewport } from 'next';
import './globals.css';

// Sin dominio definido: se usa el del despliegue de Vercel o localhost. Cuando exista dominio,
// puedes definir NEXT_PUBLIC_SITE_URL (opcional) en Vercel.
const site =
  process.env.NEXT_PUBLIC_SITE_URL || (process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : 'http://localhost:3000');

const title = 'Haciendas Santa Anna | Terrenos en Chiapas';
const description =
  'Terrenos desde $137,500 MXN. Apartado desde $10,000, enganche de $35,000 y crédito a 24 meses. Conoce las zonas Premium, Intermedia y Grandes Proyectos.';

export const metadata: Metadata = {
  metadataBase: new URL(site),
  title,
  description,
  openGraph: {
    title,
    description,
    type: 'website',
    locale: 'es_MX',
    images: [{ url: '/img/og.jpg', width: 1200, height: 630, alt: 'Terrenos en Haciendas Santa Anna' }],
  },
  twitter: { card: 'summary_large_image', title, description, images: ['/img/og.jpg'] },
};

export const viewport: Viewport = { width: 'device-width', initialScale: 1, themeColor: '#14233a' };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}
