import type { Metadata } from 'next';
import Link from 'next/link';
import { CONTACT, DEVELOPMENT } from '@/lib/config';

export const metadata: Metadata = {
  title: 'Aviso de Privacidad | Haciendas Santa Anna',
  description: 'Aviso de privacidad y derechos ARCO de Desarrollos Inmobiliarios KAHT S.A. de C.V.',
  robots: { index: false },
};

export default function Privacy() {
  return (
    <main className="legal">
      <div className="wrap wrap--narrow">
        <Link href="/" className="linkbtn">← Volver al sitio</Link>
        <p className="notice" role="note">
          <strong>Borrador sujeto a validación legal.</strong> Este aviso debe ser revisado y aprobado por un
          profesional jurídico antes de su publicación definitiva.
        </p>
        <h1>Aviso de Privacidad</h1>

        <h2>1. Responsable</h2>
        <p>
          {DEVELOPMENT.developer} (&ldquo;KAHT&rdquo;), responsable del tratamiento de tus datos personales.
          <br />Domicilio: {DEVELOPMENT.location}.
          <br />Teléfono: {CONTACT.phoneDisplay}.
        </p>

        <h2>2. Datos que se solicitan</h2>
        <p>
          Nombre, teléfono o WhatsApp, zona de interés, presupuesto aproximado, forma de pago, solicitud de visita y,
          opcionalmente, un mensaje. Las respuestas del cuestionario se usan para orientarte hacia una zona.
        </p>

        <h2>3. Finalidades</h2>
        <p>
          Atender tu solicitud de información, contactarte por WhatsApp o teléfono, dar seguimiento a tu interés en los
          terrenos y coordinar, en su caso, una visita al desarrollo.
        </p>

        <h2>4. Cómo se envían tus datos</h2>
        <p>
          Este sitio <strong>no almacena</strong> los datos del formulario ni del cuestionario. Al presionar
          &ldquo;Continuar por WhatsApp&rdquo; se prepara un mensaje que tú decides enviar al número {CONTACT.phoneDisplay}. Una vez
          enviado, WhatsApp y su proveedor tratan el mensaje conforme a sus propias políticas. El sitio no utiliza
          cookies de seguimiento, herramientas de analítica ni publicidad.
        </p>

        <h2>5. Derechos ARCO</h2>
        <p>Tienes derecho a:</p>
        <ul>
          <li><strong>Acceso:</strong> conocer qué datos personales tenemos de ti y cómo los usamos.</li>
          <li><strong>Rectificación:</strong> solicitar que corrijamos tus datos si son inexactos o están incompletos.</li>
          <li><strong>Cancelación:</strong> pedir que eliminemos tus datos de nuestros registros.</li>
          <li><strong>Oposición:</strong> oponerte al uso de tus datos para fines específicos.</li>
        </ul>

        <h2>6. Cómo presentar una solicitud</h2>
        <p>
          Comunícate al teléfono o WhatsApp {CONTACT.phoneDisplay} o acude al domicilio indicado. Tu solicitud debe
          contener:
        </p>
        <ul>
          <li>Tu nombre completo y un medio para responderte.</li>
          <li>Un documento que acredite tu identidad (o la de tu representante).</li>
          <li>La descripción clara de los datos y del derecho que deseas ejercer.</li>
          <li>Cualquier elemento que facilite localizar tus datos.</li>
        </ul>

        <h2>7. Revocación del consentimiento</h2>
        <p>
          Puedes revocar tu consentimiento en cualquier momento por los mismos medios y con la misma información
          descrita arriba. Dejaremos de contactarte, salvo cuando exista una obligación legal que lo impida.
        </p>

        <h2>8. Cambios al aviso</h2>
        <p>Cualquier modificación se publicará en esta misma página.</p>
      </div>
    </main>
  );
}
