import { Benefits, Footer, Gallery, Header, Hero, Location, Payments, StickyCta, Zones } from '@/components/Sections';
import LeadSection from '@/components/LeadSection';

export default function Home() {
  return (
    <>
      <Header />
      <main>
        <Hero />
        <Zones />
        <Payments />
        <Benefits />
        <Gallery />
        <Location />
        <LeadSection />
      </main>
      <Footer />
      <StickyCta />
    </>
  );
}
