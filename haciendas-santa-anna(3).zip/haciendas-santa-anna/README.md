# Haciendas Santa Anna — Landing page

Next.js 14 (App Router) + TypeScript. Sin analítica, sin píxeles, sin integraciones externas.
Los prospectos continúan por WhatsApp (962 179 7743) con un mensaje prellenado.

## Desplegar en Vercel
1. Sube esta carpeta a un repositorio de GitHub (o usa `vercel` desde la terminal).
2. En vercel.com → *Add New → Project* → importa el repositorio. Framework: Next.js (se detecta solo).
3. Pulsa *Deploy*. No se requieren variables de entorno.
4. Cuando tengas dominio: *Settings → Domains*, y opcionalmente define `NEXT_PUBLIC_SITE_URL` para las vistas previas al compartir.

Local: `npm install` → `npm run dev` (desarrollo) o `npm run build && npm start`.

## Dónde editar
- `lib/config.ts`: precios, zonas, textos, número de WhatsApp, enlace de Google Maps, galería.
- `lib/quiz.ts`: preguntas y puntaje orientativo (Lead inicial / tibio / caliente).
- `lib/whatsapp.ts`: mensajes prellenados.
- `app/aviso-de-privacidad/page.tsx`: aviso de privacidad (borrador sujeto a validación legal).
- `public/img`, `public/video`: fotos, logos y video optimizados.

## Pruebas
Ejecutadas: lógica del quiz (puntaje, niveles, zona sugerida), enlaces y codificación de WhatsApp, renderizado de la página y del aviso (HTML), búsqueda de textos prohibidos (12/30 meses, precios antiguos, Tapachula, pixel/analytics/Sheets), presencia de todas las imágenes y el video, ausencia de desborde horizontal y carga de imágenes en 390, 820 y 1366 px.
NO ejecutadas (el entorno no tenía red): `npm install`, `npm run build`, interacción en navegador del quiz y del formulario (validación, apertura de WhatsApp). Ejecuta `npm run build` antes de publicar.

## Pendiente
- Validación legal del aviso de privacidad.
- Ubicación confirmada por el cliente: Cantón El Sacrificio, municipio de Tuxtla Chico, Chiapas.
- Dominio.
- Anuncios de Meta con precios o plazos antiguos deben actualizarse.
